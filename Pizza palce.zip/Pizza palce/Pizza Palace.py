"""
Author: Arionna Fellows
Date Written: 07/18/24
Assignment: Pizza Palace
Short Desc: The purpose of this assignment is to make a GUI program that lets the user order pizza.
"""
#import tkinter
from tkinter import *

#Tk class
root = Tk()

#tittle of window
root.title("Pizza Palace")

#Pizza order function
def pizza_order():

    #total price
    total = 0

    if size.get()=="" -1:
        ValueError("Select size")
        return
    else:
        selected_size = size_list[size.get()]
        size_price = size_dict[selected_size]
        
        #adding prices with sizes
        total = total + size_price

        if crust.get() == -1:
            ValueError("Select crust")
            return
        else:
            selected_crust = crust_list[crust.get()]
            crust_price = crust_dict[selected_crust]

            #adding crust with total
            total = total + crust_price

            #Adding topping with total price
            if sausage.get() == 1:
                total = total + toppings_price[0]
            if pineapples.get() == 1:
                total = total + toppings_price[1]
            if archovies.get() == 1:
                total = total + toppings_price[2]
            if pepperoni.get() == 1:
                total = total + toppings_price[3]
                
    #order message
    message.info("f Your order was placed"
                f"\nSize-{selected_size}\n - {selected_crust} \n Total - ${total}")
            
    #Select pizza Size
    Label(root, text="Select Pizza Size", font= ("Ariel")).place(x=15, y =105)
    Label(root, text = "Price", font=("Ariel")).place(x=15, y=135)
    Label(root, text = "Topping", font = ("Ariel")).place(x=115, y=135)
    size = IntVar()
    size.set(-1)

    #size_dict shows different sizes and prices
    size_dict = {"Small": 10, "Medium": 15, "Large": 20, "XtraLarge": 25}
    size_list=["Small", "Medium", "Large"]
    size_price= [10, 15, 20, 25]

    #Create Buttons and Labels for size
    for i in range (0,len(size_list)):
        button = Button(root, text = size_list[i], variable=size, value=i, font=("Ariel", 14))
        Label(root, text = f"${size_price[i]}").place(x = 15, y= 167 + i * 25)
        button.place(x=95, y= 165 + i * 25)
            
                    
                                
    
